<?php
include("TrafficCounterUtilityFunc.php");

// This script processes an AJAX request to send data that is graphed on client side
if(isset($_POST['StatisticsStartDate']) && isset($_POST['StatisticsEndDate'])) {
    $post_result = array(); // declare associative array with Time stamp as keys and count as value

    // Retrieve the start and end date from AJAX request
    $phpFormatStartDate = $_POST['StatisticsStartDate'];
    $phpFormatEndDate = $_POST['StatisticsEndDate'];
    $lot = $_POST['lot']

    // Get columns (timestamp and count) values between start and end dates provided by the AJAX request
    $database_result = GetTimeStampAndCountBetweenDates($phpFormatStartDate, $phpFormatEndDate, $lot);

    // Get an array of Time stamps and another array of number of people in the last 15 minutes
    $TimeStamp_result = array();
    foreach($database_result as $element) {
        array_push($TimeStamp_result, $element[0]);
    }
    $Count_result = array();
    foreach($database_result as $element) {
        array_push($Count_result, $element[1]);
    }

    // make a JSON style object with Time stamps as keys and number of people aka Count as value
    for($i = 0; $i < Count($TimeStamp_result); $i++) {
        $post_result[ (string)date("Y-m-d H:i:s", (string)$TimeStamp_result[$i]) ] = $Count_result[$i];
    }

    // tells the server to return JSON type result and not html
    header('Content-Type: application/json');

    //encode the array to a json object
    echo json_encode($post_result);
    die();
}

?>