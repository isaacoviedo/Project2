<?php
include("TrafficCounterUtilityFunc.php");

	if(isset($_POST['predictDay'])) {
	    $post_result = array(); // declare associative array with Time stamp as keys and count as value
	    // $lot = $_POST['lot'];
	    // Retrieve the start and end date from AJAX request
	    $predictDay = $_POST['predictDay'];
	    $beginDate = dayToDate($predictDay);

	    // averages traffic data for this day across past five weeks
	    for($weeksAgo=0;$weeksAgo<5;$weeksAgo++) {
	    	$dayTimestamp = strtotime($beginDate . " -" . $weeksAgo . " weeks");

	    	// gets traffic data for each hour in the day
	    	for($hour=0;$hour<24;$hour++) {
	    		$hourTimestamp = $dayTimestamp + $hour*3600;
	    		$nextHourTimestamp = $hourTimestamp + 3600;
	    		$hourString = date("Y-m-d H:i:s", $hourTimestamp);
	    		$nextHourString = date("Y-m-d H:i:s", $nextHourTimestamp);

	    		$trafficData = GetTimeStampAndCountBetweenDates($hourString, $nextHourString, $lot);
	    		$count = $trafficData[0];
	    		// echo $count . "\n";

	    		$post_result[ (string)$hour ] += $count;
	    	}
	    }

	    foreach($post_result as &$sum_count) {
	    	$sum_count /= 5; // sum -> average across 5 weeks
	    }

	    // tells the server to return JSON type result and not html
	    header('Content-Type: application/json');

	    //encode the array to a json object
	    echo json_encode($post_result);
	    die();
	}


	function dayToDate($dayName) {
		$timestamp = strtotime($dayName . " this week");
		$date = date("Y-m-d", $timestamp);
		return $date;
	}

?>