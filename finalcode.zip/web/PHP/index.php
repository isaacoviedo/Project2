<!DOCTYPE html>
<html lang="en-US">

<head>
    <meta charset="UTF-8">
    <title>Usage Analysis</title>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <!--Load the AJAX API-->
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript"></script>
    <script type="text/javascript" src="../JS/DisplayGoogleChart.js"> </script>
</head>
	<div class = "header">
	    <h2 align="center">Parking Lot Traffic Utility</h2>
	</div>
<body class="MainContent">
	<div class="MainContentContainer">
		<?php
		    include("DisplayUserChartAndOptions.php");
		?>
	</div>
</body>
</html>